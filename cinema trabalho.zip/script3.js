var table= document.querySelector('table');
c1=0;
c2=0;
table.addEventListener('click' , function(evento){
   var celula= evento.target
 if((celula.className!="vago") && (celula.className!="corredor") &&(celula.className!="tabela")){
   if((evento.altKey == true) && (celula.className!="amarelo") && (celula.className!="rosa")){
     celula.className='amarelo';
     c1++;
   }
   if ((evento.ctrlKey == true) && (celula.className!="amarelo") && (celula.className!="rosa")){
      celula.className='rosa';
      c2++;
   }
   if (evento.shiftKey == true){
     if (celula.className == "amarelo"){
       c1--;
       celula.className='descelecionar';
     }
     if(celula.className =="rosa"){
       c2--;
       celula.className='descelecionar';
     }
   }
 }
});
onkeyup= function(){
  var inteira=document.querySelector('input').value;
  var meia= parseFloat(inteira/2);
  var precointeira=document.getElementById('inteira');
  var precomeia=document.getElementById('meia');
  var total= document.getElementById('conta');
  var output=document.getElementsByTagName('output')[0];
  output.innerHTML=meia;
  inteira*=c1;
  meia*=c2;
  total= "Total = " + parseInt(inteira+meia) + " Reais";
  if(c1<0){
    inteira= c1 + " Entrada Inteira = " + inteira + " Reais";
  }
  if (c1==1){
     inteira= c1 + " Entrada Inteira =  " + inteira + " Reais";
  }
  if(c1>1){
    inteira= c1 + " Entradas Inteiras = " + inteira + " Reais";
  }
  if (c2<0){
    meia= c2 + " Meia Entrada = " + meia + " Reais";
  }
  if (c2==1){
     meia= c2 + " Meia Entrada = " + meia + " Reais";
  }
  if (c2>1){
    meia= c2 + " Meias Entradas = " + meia + " Reais";
  }
  precointeira.innerHTML=(inteira);
  precomeia.innerHTML= (meia);
  conta.innerHTML=(total);
}
